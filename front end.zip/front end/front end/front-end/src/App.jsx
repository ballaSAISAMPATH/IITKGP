import React from 'react'
import Form from './Form'
import './App.css'
export default function App() {
  return (
    <div>
      <Form/>
    </div>
  )
}
